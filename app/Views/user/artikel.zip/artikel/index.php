<?= $this->extend('user/template/template') ?>
<?= $this->Section('content'); ?>

<section class="intro-single page-header-1" style="display: flex; align-items: center; justify-content: center;">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-8">
                <div class="title-single-box">
                    <h1 class="title-single text-white">
                        <?php foreach ($profil as $perusahaan) :
                            echo lang('Blog.titleOurarticle');
                            if (!empty($perusahaan)) {
                                echo ' ' . $perusahaan->nama_perusahaan;
                            }
                        endforeach; ?>
                    </h1>
                </div>
            </div>
            <div class="col-md-12 col-lg-4">
                <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item justify-content-center">
                            <a href="<?= base_url('/') ?>"><?php echo lang('Blog.headerHome'); ?></a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <?php echo lang('Blog.headerArticle') ?>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</section>
<!-- End Intro Single-->

<!-- ======= Latest News Section ======= -->
<section class="section-news section-t8">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title-wrap d-flex justify-content-between">
                    <div class="title-box">
                        <h2 class="title-a">
                            Artikel Terbaru
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="swiper">
            <div class="swiper-wrapper" style="display: flex; gap: 5px; justify-content: center; align-items: center;">
                <?php foreach ($artikelterbaru as $row) : ?>
                    <div class="card-box-b card-shadow news-box" style="margin-right: 5px;">
                        <div class="img-box-b">
                            <img class="img-b img-fluid" style="object-fit: cover;" src="<?= base_url('asset-user') ?>/images/<?= $row->foto_artikel; ?>" alt="<?= $row->judul_artikel; ?>" loading="lazy">
                        </div>
                        <div class="card-overlay">
                            <div class="card-header-b">
                                <div class="card-title-b">
                                    <h2 class="title-2">
                                        <a href="<?= base_url('/artikel/detail/' . $row->id_artikel) ?>"><?= substr(strip_tags($row->judul_artikel), 0, 10) ?>...</a>
                                    </h2>
                                </div>
                                <div class="card-date">
                                    <span><?= date('d F Y', strtotime($row->created_at)); ?></span>
                                </div>
                                <p><?= substr(strip_tags($row->deskripsi_artikel), 0, 30) ?>...</p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<!-- End Latest News Section -->
<br>
<br>

<?= $this->endSection('content'); ?>
